#!/bin/bash
gcc -Wall -Wextra -o example -I../src/ ../src/uuid4.c example.c
